﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace socketupdate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Send archive";
            if(DialogResult.OK == ofd.ShowDialog())
            {
                clickSelect.Text = ofd.FileName;
            } else
            {

            }
        }

        private void startcon_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(guna2TextBox1.Text) 
                || string.IsNullOrEmpty(portN.Value.ToString()) ||
                clickSelect.Text == "Click here to upload your file")
            {
                status.ForeColor = Color.Red;
                status.Text = "Wrong details";
                return;
            }

            string enderecoIP = guna2TextBox1.Text;
            int port = (int)portN.Value;
            string arquivo = clickSelect.Text;
            api.FTupload.enderecoIp = enderecoIP;
            api.FTupload.portHost = port;


            
            try
            {
                Task.Factory.StartNew(() =>
                {
                    api.FTupload.sendFile(arquivo);
                });
            } catch (Exception ex)
            {
                
                status.ForeColor=Color.Red;
                status.Text = "Error: " + ex.Message;
            }
        }
    }
}
