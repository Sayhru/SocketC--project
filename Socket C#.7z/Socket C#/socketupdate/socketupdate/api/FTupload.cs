﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace socketupdate.api
{
    internal class FTupload
    {
        //Default values and the init of some variables;
        static IPEndPoint ip;
        static Socket socket;
        public static String enderecoIp = "127.0.0.1";
        public static int portHost = 1000;
        //Default folder path and a init of a listbox for give erros or some status;
        public static string pastaArquivo = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\";
        public static Label listMensagem;

        public static void sendFile(string arquivo)
        {
            try
            {
                //init the variables and parse the ip's | socket is the type of the connection and ther protocol's;
                ip = new IPEndPoint(IPAddress.Parse(enderecoIp), portHost);
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                string pasta = "";


                pasta += arquivo.Substring(0, arquivo.LastIndexOf(@"\") + 1);

                arquivo = arquivo.Substring(arquivo.LastIndexOf(@"\") + 1);
                //getting bytes;
                byte[] nameByte = Encoding.UTF8.GetBytes(arquivo);
                //max size file 
                if (nameByte.Length > 50000 * 1024)
                {
                    listMensagem.ForeColor = System.Drawing.Color.Red;
                    listMensagem.Text = "The maxium size file is 50MB !";
                    return;
                }
                //The complete path
                string caminhoCompleto = pasta + arquivo;

                //get all bytes of the file using the complete path
                byte[] fileData = File.ReadAllBytes(caminhoCompleto);
                //every data here:
                byte[] clientData = new byte[4 + nameByte.Length + fileData.Length];
                //Convert and get the exactly lenght of bytes
                byte[] nameLen = BitConverter.GetBytes(nameByte.Length);

                nameLen.CopyTo(clientData, 0);
                nameByte.CopyTo(clientData, 4);
                fileData.CopyTo(clientData, 4 + nameByte.Length);
                socket.Connect(ip);
                socket.Send(clientData, 0, clientData.Length, 0);
                socket.Close();

                listMensagem.ForeColor = System.Drawing.Color.Green;
                listMensagem.Text = "Archive sent [" + arquivo + "]";


            }
            catch (Exception ex)
            {

                listMensagem.ForeColor = System.Drawing.Color.Red;
                listMensagem.Text = "The server isn't responsing: " + ex.Message;
            }
            finally
            {
                {
                    socket.Close();
                }

            }

        }   
    }
}
