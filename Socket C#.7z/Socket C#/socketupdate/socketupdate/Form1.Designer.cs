﻿namespace socketupdate
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.status = new System.Windows.Forms.Label();
            this.clickSelect = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.portN = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.startcon = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.portN)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.IndianRed;
            this.guna2Panel1.Controls.Add(this.status);
            this.guna2Panel1.Controls.Add(this.clickSelect);
            this.guna2Panel1.Location = new System.Drawing.Point(10, 167);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(781, 190);
            this.guna2Panel1.TabIndex = 14;
            // 
            // status
            // 
            this.status.AllowDrop = true;
            this.status.Font = new System.Drawing.Font("Impact", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status.Location = new System.Drawing.Point(6, 112);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(772, 78);
            this.status.TabIndex = 10;
            this.status.Text = "Status: ";
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clickSelect
            // 
            this.clickSelect.AllowDrop = true;
            this.clickSelect.Font = new System.Drawing.Font("Impact", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clickSelect.Location = new System.Drawing.Point(6, 0);
            this.clickSelect.Name = "clickSelect";
            this.clickSelect.Size = new System.Drawing.Size(772, 112);
            this.clickSelect.TabIndex = 9;
            this.clickSelect.Text = "Click here to upload your file";
            this.clickSelect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.clickSelect.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::socketupdate.Properties.Resources.icone2;
            this.pictureBox1.Location = new System.Drawing.Point(248, 20);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 60);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Impact", 17.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(315, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 36);
            this.label2.TabIndex = 12;
            this.label2.Text = "Server uploader";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // portN
            // 
            this.portN.BackColor = System.Drawing.Color.Transparent;
            this.portN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.portN.DisabledState.Parent = this.portN;
            this.portN.FocusedState.Parent = this.portN;
            this.portN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.portN.ForeColor = System.Drawing.Color.Black;
            this.portN.Location = new System.Drawing.Point(470, 100);
            this.portN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.portN.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.portN.Name = "portN";
            this.portN.ShadowDecoration.Parent = this.portN;
            this.portN.Size = new System.Drawing.Size(100, 36);
            this.portN.TabIndex = 11;
            this.portN.UpDownButtonFillColor = System.Drawing.Color.IndianRed;
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderRadius = 15;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.FocusedState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.HoverState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Location = new System.Drawing.Point(167, 90);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(5);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderText = "127.0.0.1";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.ShadowDecoration.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Size = new System.Drawing.Size(276, 54);
            this.guna2TextBox1.TabIndex = 10;
            // 
            // startcon
            // 
            this.startcon.BorderRadius = 25;
            this.startcon.CheckedState.Parent = this.startcon;
            this.startcon.CustomImages.Parent = this.startcon;
            this.startcon.FillColor = System.Drawing.Color.IndianRed;
            this.startcon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.startcon.ForeColor = System.Drawing.Color.White;
            this.startcon.HoverState.Parent = this.startcon;
            this.startcon.Location = new System.Drawing.Point(248, 371);
            this.startcon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.startcon.Name = "startcon";
            this.startcon.ShadowDecoration.Parent = this.startcon;
            this.startcon.Size = new System.Drawing.Size(310, 71);
            this.startcon.TabIndex = 9;
            this.startcon.Text = "Start connection";
            this.startcon.Click += new System.EventHandler(this.startcon_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.portN);
            this.Controls.Add(this.guna2TextBox1);
            this.Controls.Add(this.startcon);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Server uploader";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.portN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label status;
        private System.Windows.Forms.Label clickSelect;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2NumericUpDown portN;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2Button startcon;
    }
}

