﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace socket.Api
{
    internal class FTserver
    {

            //Default values and the init of some variables;
            static IPEndPoint ip;
            static Socket socket;
        public static String enderecoIp = "127.0.0.1";
        public static int portHost = 1000;
        //Default folder path and a init of a listbox for give erros or some status;
        public static string pastaArquivo = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\";
        public static ListBox listMensagem;

        public static void iniciarServidor()
        {
            try
            {
                //init = parse 127.0.0.1 ':' 1000
                ip = new IPEndPoint(IPAddress.Parse(enderecoIp), portHost);
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
                socket.Bind(ip);

            }
            catch (Exception ex)
            {
                //Invoke a lambada for give the error msg;
                listMensagem.Invoke(new Action(() => {
                    listMensagem.Items.Add("Error at start server: " + ex.Message);
                    listMensagem.SetSelected(listMensagem.Items.Count - 1, true);
                }));
                return;
            }
            //new try catch for get the name file, and the file XD
            try
            {
                //Working message;
                socket.Listen(100);
                listMensagem.Invoke(new Action(() => {
                    listMensagem.Items.Add("Working server, waiting for recive some file !");
                    listMensagem.SetSelected(listMensagem.Items.Count - 1, true);
                }));
                //initing and atribuing a new socket for this method;
                Socket clientSocket = socket.Accept();
                clientSocket.ReceiveBufferSize = 16384;
                //max size is 50MB;
                byte[] dadosCliente = new byte[1024 * 50000];
                //getting the values: name, quantity of bytes and the leng of name;
                int lengBytesRecebidos = clientSocket.Receive(dadosCliente, dadosCliente.Length, 0);
                int lengNameFile = BitConverter.ToInt32(dadosCliente, 0);
                string nameFile = Encoding.UTF8.GetString(dadosCliente, 4, lengNameFile);

                BinaryWriter bw = new BinaryWriter(File.Open(pastaArquivo + nameFile, FileMode.Append));
                bw.Write(dadosCliente, 4 + lengNameFile, lengBytesRecebidos - 4 - lengNameFile);

                while (lengBytesRecebidos > 0)
                {

                    lengBytesRecebidos = clientSocket.Receive(dadosCliente, dadosCliente.Length, 0);
                    if (lengBytesRecebidos == 0)
                    {
                        bw.Close();
                    }
                    else
                    {
                        bw.Write(dadosCliente, 0, lengBytesRecebidos);
                    }

                }

                listMensagem.Invoke(new Action(() =>
                {
                    //Sucessfull mensange uploading file;
                    listMensagem.Items.Add("Archive recived [" + nameFile + "] by [" + ip + ":" + portHost + "]");
                    listMensagem.SetSelected(listMensagem.Items.Count - 1, true);
                }));
                //Close the instances before end this method;
                bw.Close();
                clientSocket.Close();
            }
            catch (SocketException ex)
            {
                listMensagem.Invoke(new Action(() =>
                {
                    listMensagem.Items.Add("Errot at uploading the file: " + ex.Message);
                    listMensagem.SetSelected(listMensagem.Items.Count - 1, true);
                }));
            }
            finally
            {
                socket.Close();
                socket.Dispose();
                iniciarServidor();
            }

        }


    }
}
