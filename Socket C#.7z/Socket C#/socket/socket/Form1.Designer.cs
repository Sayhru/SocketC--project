﻿namespace socket
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.startcon = new Guna.UI2.WinForms.Guna2Button();
            this.closecon = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.portN = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtFile = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.portN)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // startcon
            // 
            this.startcon.BorderRadius = 25;
            this.startcon.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.startcon.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.startcon.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.startcon.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.startcon.FillColor = System.Drawing.Color.IndianRed;
            this.startcon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.startcon.ForeColor = System.Drawing.Color.White;
            this.startcon.Location = new System.Drawing.Point(85, 165);
            this.startcon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.startcon.Name = "startcon";
            this.startcon.Size = new System.Drawing.Size(273, 46);
            this.startcon.TabIndex = 0;
            this.startcon.Text = "Start connection";
            this.startcon.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // closecon
            // 
            this.closecon.BorderRadius = 25;
            this.closecon.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.closecon.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.closecon.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.closecon.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.closecon.FillColor = System.Drawing.Color.IndianRed;
            this.closecon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.closecon.ForeColor = System.Drawing.Color.White;
            this.closecon.Location = new System.Drawing.Point(441, 165);
            this.closecon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.closecon.Name = "closecon";
            this.closecon.Size = new System.Drawing.Size(269, 46);
            this.closecon.TabIndex = 1;
            this.closecon.Text = "Close connection";
            this.closecon.Click += new System.EventHandler(this.closecon_Click);
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderRadius = 15;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.guna2TextBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(169, 82);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(5);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderText = "127.0.0.1";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(276, 54);
            this.guna2TextBox1.TabIndex = 2;
            this.guna2TextBox1.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // portN
            // 
            this.portN.BackColor = System.Drawing.Color.Transparent;
            this.portN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.portN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.portN.ForeColor = System.Drawing.Color.Black;
            this.portN.Location = new System.Drawing.Point(472, 92);
            this.portN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.portN.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.portN.Name = "portN";
            this.portN.Size = new System.Drawing.Size(100, 36);
            this.portN.TabIndex = 3;
            this.portN.UpDownButtonFillColor = System.Drawing.Color.IndianRed;
            this.portN.ValueChanged += new System.EventHandler(this.portN_ValueChanged);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.AllowDrop = true;
            this.guna2Panel1.BackColor = System.Drawing.Color.IndianRed;
            this.guna2Panel1.Controls.Add(this.listBox1);
            this.guna2Panel1.Controls.Add(this.txtFile);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 225);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(781, 229);
            this.guna2Panel1.TabIndex = 4;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(19, 50);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(741, 164);
            this.listBox1.TabIndex = 1;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // txtFile
            // 
            this.txtFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFile.Location = new System.Drawing.Point(13, 11);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(747, 37);
            this.txtFile.TabIndex = 0;
            this.txtFile.Text = "Click here to select your file";
            this.txtFile.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.txtFile.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Impact", 17.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(269, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 36);
            this.label2.TabIndex = 6;
            this.label2.Text = "Server Downloader";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::socket.Properties.Resources.icone2;
            this.pictureBox1.Location = new System.Drawing.Point(199, 12);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 64);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(805, 466);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.portN);
            this.Controls.Add(this.guna2TextBox1);
            this.Controls.Add(this.closecon);
            this.Controls.Add(this.startcon);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Server downloader";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.portN)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button startcon;
        private Guna.UI2.WinForms.Guna2Button closecon;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label txtFile;
        private Guna.UI2.WinForms.Guna2NumericUpDown portN;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

