﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace socket
{
    public partial class Form1 : Form
    {
        Task work;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtFile.Text = Api.FTserver.pastaArquivo;
            Api.FTserver.listMensagem = listBox1;

        }
        private void guna2Button1_Click(object sender, EventArgs e)
        {

            try
            {

                Api.FTserver.enderecoIp = guna2TextBox1.Text;
                Api.FTserver.portHost = (int)portN.Value;

                work = Task.Factory.StartNew(() => {
                    Api.FTserver.iniciarServidor();
                });

            } catch (Exception ex) 
            {
                listBox1.Invoke(new Action(() =>
                {
                    listBox1.Items.Add("Error at connection: " + ex.Message);
                    listBox1.SetSelected(listBox1.Items.Count -1, true);

                }));
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if(dialog.ShowDialog() != DialogResult.Cancel)
            {
               Api.FTserver.pastaArquivo = dialog.SelectedPath + @"\";
                txtFile.Text = dialog.SelectedPath; 
            }
        }

        private void closecon_Click(object sender, EventArgs e)
        {
            try
            {
                Application.Restart();

            } catch (Exception ex)
            {
                listBox1.Invoke(new Action(() =>
                {
                    listBox1.Items.Add("Error at connection: " + ex.Message);
                    listBox1.SetSelected(listBox1.Items.Count - 1, true);

                }));
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void portN_ValueChanged(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
